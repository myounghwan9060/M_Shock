package com.cj.mobile;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import java.net.URL;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cj.util.SmartProperties;

public class M_Shock_004 {
	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	WebElement element = null;
	boolean setupSuccess = true;
	private String M_URL = null;
	boolean isExist1 = false;
	boolean isExist2 = false;
	boolean isExist3 = false;
	//int[] ScheduleNum = {2,3,4,5,6,7,8,9,10}; 
	
	/**
	 * 
	 * @author 김명환
	 * Date : 2018-05-03  
	 * Subject : CJ Mall 운영  
	 * Name : M_Shock_002  
	 * Scenario : CJmall > 쇼크라이브 > 편성표 > 예고방송페이지(PGM배너)  
	 * Assertion : 예고방송 페이지 진입 확인
	 *   
	 */

	@Before
	public void setUp() throws Exception {

		SmartProperties sp = SmartProperties.getInstance();
		M_URL = sp.getProperty("M_URL");
		
		
		
		
		Thread.sleep(5000);
		DesiredCapabilities caps = new DesiredCapabilities();
		caps = DesiredCapabilities.android();

		// device name은 큰 의미없음. LG폰도 이 옵션으로 수행됨
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "LGF460S859d639d");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		caps.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");

		URL appiumUrl = new URL("http://127.0.0.1:4723/wd/hub");

		System.out.println("Start driver.");
		driver = new AndroidDriver<WebElement>(appiumUrl, caps);

	}

	@Test
	
	
	public void schedule_04() throws InterruptedException {
		
			driver.get(M_URL);
			
			// 알럿 발생확인
			isExist1 = existElement(driver, By.xpath(".//*[@id='notToday']/label"), "오늘 하루 보이지 않기");
			if (isExist1) {
				// 오늘 하루 보지 않기 버튼 클릭
				driver.findElement(By.xpath(".//*[@id='notToday']/label")).click();
				System.out.println("오늘 하루 보지 않기 버튼 클릭");
				Thread.sleep(3000);
			} else {
				// 알럿이 없는 경우
				System.out.println("알럿 없음 다음 내용 수행");
				Thread.sleep(3000);
			}

			// 쇼크라이브
			driver.findElement(By.linkText("쇼크LIVE")).click();
			System.out.println("쇼크LIVE 진입");
			Thread.sleep(3000);
					
	        WebElement searchBtn = driver.findElement(By.cssSelector("#moduleArea > div.module_bx.dm0027"));
	        Actions action = new Actions(driver);
	        action.moveToElement(searchBtn).build().perform();
	        Thread.sleep(3000);
	        
			// 편성표 보기 버튼 클릭
			driver.findElement(By.cssSelector("#moduleArea > div.module_bx.dm0027 > div > div > a > div.btn_area > button > span")).click();
			System.out.println("편성표 보기 클릭. 편성표 진입");
			Thread.sleep(3000);
			//driver.findElement(By.cssSelector("#scheduleDate > div > ul > li:nth-child(10) > a")).click();
			//Thread.sleep(3000);		
	
			// 바로가기 버튼 선택
			
			isExist2 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[1]"), "");
			if(!isExist2) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div/div[2]/div[2]/ul/li[2]/a/span")).click();
				System.out.println("예고방송 페이지 진입 ");
				Thread.sleep(3000);
				if ("쇼크LIVE".equals(driver.findElement(By.linkText("//*[@id=\"header\"]/div/h1")).getText())) {
					System.out.println("예고방송 페이지 진입 확인. 종료 합니다.");
					Thread.sleep(3000);
					assertTrue(true);
					return;
					
				}else {
						System.out.println("복수편성입니다. 계속 진행합니다");
						Thread.sleep(3000);
					}

			}
			
			for( int x = 1; x <=10 ; ){	
				x = x++;
				isExist3 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span["+ x +"]"), "바로가기");
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span["+ x +"]")).click();
				Thread.sleep(1000);
				
				if(isExist3) {
					driver.findElement(By.cssSelector(
							"#schedulePgm > div:nth-child(1) > div.prd_wrap > div.wrap_inner.swiper-container.swiper-container-horizontal.swiper-container-android > ul > li.prd_more.swiper-slide > a")).click();
					System.out.println("예고방송 페이지 진입 ");
					Thread.sleep(3000);
					break;

				}else {
					
					System.out.println("바로가기 버튼 탐색 중 ");
					continue;
				}
				
			}
			
			if("쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText())){
				System.out.println("쇼크라이브 예고방송 페이지 진입 확인. TC종료합니다");
				assertTrue(true);
				return;
			} else {
				System.out.println("쇼크라이브 예고방송 페이지 진입 불가. TC FAIL");
				assertTrue(false);
				return;
			}
					
			
			
			}
			


	


	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}
	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		// wait.ignoring(NoSuchElementException.class);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}

}

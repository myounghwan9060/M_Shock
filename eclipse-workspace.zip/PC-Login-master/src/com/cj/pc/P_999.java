package com.cj.pc;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * 
 * @author 조성주
 * Date : 2017-06-13
 * Subject : CJ Mall 운영 
 * Name : TC_62
 * Scenario : 임의의 상품 무통장 입금 으로 결제하기
 * Assertion : 결제완료 Text 체크
 *
 */ 

public class P_999 {
	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	boolean isExist1 = false;
	
	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test
	public void p_999() throws Exception {
		// 로그인
		driver.get("https://www.baeminchan.com/");
		driver.findElement(By.xpath("//*[@id=\"lnb\"]/ul/li[1]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"member_id\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"member_id\"]")).sendKeys("growmaster@naver.com");
		driver.findElement(By.xpath("//*[@id=\"pwd\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"pwd\"]")).sendKeys("cjmall2$");
		driver.findElement(By.xpath("//*[@id=\"login\"]/div[1]/form/fieldset/button")).click();
		System.out.println("로그인 성공");
		Thread.sleep(3000);
		// 상품진입
		driver.findElement(By.xpath("//*[@id=\"navi_wrap\"]/nav/ul/li[1]/a/span")).click();
		Thread.sleep(3000);
		WebElement searchBtn1 = driver.findElement(By.xpath("//*[@id=\"container\"]/div[2]/div[1]/h2"));
		Actions action2 = new Actions(driver);
		action2.moveToElement(searchBtn1).perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"products\"]/li[1]/div[1]/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div/form/fieldset/button")).click();
		driver.findElement(By.xpath("//*[@id=\"go_to_cart\"]")).click();
		Thread.sleep(3000);
		WebElement searchBtn2 = driver.findElement(By.xpath("//*[@id=\"footer\"]/div[1]/div/ul"));
		Actions action3 = new Actions(driver);
		action3.moveToElement(searchBtn2).perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"btn_select_receipt_date\"]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div[2]/button")).click();
		Thread.sleep(3000);
		WebElement searchBtn3 = driver.findElement(By.xpath("//*[@id=\"footer\"]/div[1]/div/ul"));
		Actions action4 = new Actions(driver);
		action4.moveToElement(searchBtn3).perform();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"door_number_pass\"]/td/ul/li[2]/span/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"all_pay_types\"]/table/tbody/tr/td/ul[1]/li[3]/span/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"ordFrm\"]/ul/li/span/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"order1\"]/button")).click();
		Thread.sleep(3000);
		
		
		
		
		driver.switchTo().frame(1);
		driver.findElement(By.xpath("//*[@id=\"main_agreed_info\"]/fieldset/div[1]/span/label/strong")).click();
		driver.findElement(By.xpath("//*[@id=\"main_agreed_info\"]/div/p[2]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"BANKCODE0\"]")).click();
		Thread.sleep(1000);
		System.out.println("2");
		driver.findElement(By.xpath("//*[@id=\"LGD_ACCOUNTOWNER\"]")).click();
		System.out.println("3");
		//driver.findElement(By.xpath("//*[@id=\\\"LGD_ACCOUNTOWNER\\\"]")).clear();
		driver.findElement(By.cssSelector("#LGD_ACCOUNTOWNER")).sendKeys("김명환");
		System.out.println("4");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"cashreceiptLayer\"]/dl[1]/dd/ul/li[3]/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"chk_payinput_ul\"]/li/label")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"LGD_NEXT\"]/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"LGD_NEXT\"]/a")).click();
		Thread.sleep(3000);
		driver.switchTo().defaultContent(); 

		// text check
		if ("주문이 정상적으로 완료되었습니다!".equals(driver.findElement(By.xpath("//*[@id=\"orderFinish\"]/div/h2")).getText())) {
			System.out.println("TC_999 PASS");
			assertTrue(true);
			return;
		} else {
			System.out.println("TC_999 FAIL");
			assertTrue(false);
		}

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}

}
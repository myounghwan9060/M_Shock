package com.cj.pc;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cj.util.SmartProperties;

/**
 * 
 * @author 조성주 Date : 2017-06-13
 * Subject : CJ Mall 운영 
 * Name : TC_58
 * Scenario :최근본상품 > 쇼핑찜가기 버튼 선택 > ID / PW 입력 > 로그인
 * Assertion : 쇼핑찜 Text 체크
 *
 */

public class P_059 {
	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	private String ID_1 = null;
	private String PW_1 = null;
	private String P_URL = null;
	private String PRODUCT = null;
	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		SmartProperties sp = SmartProperties.getInstance();
		ID_1 = sp.getProperty("ID_1");
		PW_1 = sp.getProperty("PW_1");
		P_URL = sp.getProperty("P_URL");
		PRODUCT = sp.getProperty("PRODUCT");
	}

	@Test
	public void p_059() throws Exception {
		driver.get(P_URL);

		// 상품진입
		driver.findElement(By.id("srh_keyword")).clear();
		driver.findElement(By.id("srh_keyword")).sendKeys(PRODUCT);
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("button._search")).click();
		driver.findElement(By.xpath("//*[@id=\"cont_listing0\"]/div[6]/ul/li/a")).click();
		System.out.println("상품진입 성공");
		driver.findElement(By.xpath("//*[@id=\"quick_menu\"]/div[1]/div[1]/ul/li[1]/a/span/span/img")).click();
		System.out.println("최근본상품 성공");
		// 찜버튼 클릭
		WebElement searchBtn = driver.findElement(By.xpath("//*[@id=\"_RECOMMEND\"]/div[1]/h4"));
		Actions action = new Actions(driver);
		action.moveToElement(searchBtn).perform();
		Thread.sleep(3000);
		
		boolean isExist1 = false;
		String jjim = null;
		isExist1 = existElement(driver, By.xpath("//*[@id=\"content\"]/div[2]/div[1]/div[2]/div[3]/div[1]/a"), "찜");
		if (isExist1) {
			jjim=  "//*[@id=\"content\"]/div[2]/div[1]/div[2]/div[3]/div[1]/a";
			System.out.println("1");
		} else {
			jjim=  "//*[@id=\"content\"]/div[2]/div[1]/div[2]/div[2]/div[1]/a";
			System.out.println("2");
		}
		
		driver.findElement(By.xpath(jjim)).click();
		System.out.println("찜 클릭");
		Thread.sleep(3000);
		// alert check
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(3000);
		System.out.println("얼럿 닫기 성공");
		
		// 로그인
		driver.findElement(By.xpath("//*[@id='id_input']")).clear();
		driver.findElement(By.xpath("//*[@id='id_input']")).sendKeys(ID_1);
		driver.findElement(By.xpath(".//*[@id='password_input']")).clear();
		driver.findElement(By.xpath(".//*[@id='password_input']")).sendKeys(PW_1);
		driver.findElement(By.xpath(".//*[@id='loginSubmit']")).click();
		Thread.sleep(3000);
		System.out.println("로그인 성공");
		Thread.sleep(3000);
		// 일반 찜버튼 //*[@id="content"]/div[2]/div[1]/div[2]/div[2]/div[1]/a
		// 매진일 경우 찜 버튼 //*[@id="content"]/div[2]/div[1]/div[2]/div[3]/div[1]/a
		WebElement searchBtn1 = driver.findElement(By.xpath("//*[@id=\"_RECOMMEND\"]/div[1]/h4"));
		Actions action1 = new Actions(driver);
		action1.moveToElement(searchBtn1).perform();
		Thread.sleep(3000);
		
		
		if ("찜".equals(
				driver.findElement(By.xpath(jjim)).getText())) {
			System.out.println("TC_59 Pass");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='go_myzone']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='aside']/div/ul[1]/li[3]/ul/li[1]/a")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div[1]/div/button")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div[2]/div/div[2]/div/div[2]/button")).click();
			assertTrue(true);
			return;
		} else {
			System.out.println("TC_59 Fail");
			assertTrue(false);
		}
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}

}
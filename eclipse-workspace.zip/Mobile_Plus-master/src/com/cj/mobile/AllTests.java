package com.cj.mobile;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ M_Plus_001.class, M_Plus_002.class, M_Plus_003.class,
		M_Plus_004.class, M_Plus_005.class, M_Plus_006.class, M_Plus_007.class, M_Plus_008.class, M_Plus_009.class,
		M_Plus_010.class, M_Plus_011.class, M_Plus_012.class, M_Plus_013.class, M_Plus_014.class, M_Plus_015.class,
		M_Plus_016.class, M_Plus_017.class, M_Plus_018.class, M_Plus_019.class, M_Plus_020.class, M_Plus_021.class,
		M_Plus_022.class, M_Plus_023.class, M_Plus_024.class, M_Plus_025.class, M_Plus_026.class, M_Plus_027.class,
		M_Plus_028.class, M_Plus_029.class, M_Plus_030.class, M_Plus_031.class, M_Plus_032.class, M_Plus_033.class,
		M_Plus_034.class, M_Plus_035.class, M_Plus_036.class, M_Plus_037.class, M_Plus_038.class, M_Plus_039.class,
		M_Plus_040.class })
public class AllTests {

}

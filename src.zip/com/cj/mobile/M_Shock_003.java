package com.cj.mobile;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;
import java.net.URL;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cj.util.SmartProperties;

public class M_Shock_003 {
	private WebDriver driver;
	private StringBuffer verificationErrors = new StringBuffer();
	WebElement element = null;
	boolean setupSuccess = true;
	private String M_URL = null;
	boolean isExist1 = false;
	boolean isExist2 = false;
	boolean isExist3 = false;
	boolean isExist4 = false;
	boolean isExist5 = false;
	boolean isExist6 = false;
	boolean isExist7 = false;
	boolean isExist8 = false;
	boolean isExist9 = false;
	boolean isExist10 = false;
	boolean isExist11 = false;
	boolean ShockLive = false;
	boolean BbunFun = false; 
	/**
	 * 
	 * @author 김명환
	 * Date : 2018-05-03  
	 * Subject : CJ Mall 운영  
	 * Name : M_Shock_002  
	 * Scenario : CJmall > 쇼크라이브 > 편성표 > 예고방송페이지(PGM배너)  
	 * Assertion : 예고방송 페이지 진입 확인
	 *   
	 */

	@Before
	public void setUp() throws Exception {

		SmartProperties sp = SmartProperties.getInstance();
		M_URL = sp.getProperty("M_URL");
		
		
		
		
		Thread.sleep(5000);
		DesiredCapabilities caps = new DesiredCapabilities();
		caps = DesiredCapabilities.android();

		// device name은 큰 의미없음. LG폰도 이 옵션으로 수행됨
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "LGF460S859d639d");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
		caps.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");

		URL appiumUrl = new URL("http://127.0.0.1:4723/wd/hub");

		System.out.println("Start driver.");
		driver = new AndroidDriver<WebElement>(appiumUrl, caps);

	}

	@Test
	
	
	public void schedule_03() throws InterruptedException {
		
			driver.get(M_URL);
			
			// 알럿 발생확인
			isExist1 = existElement(driver, By.xpath(".//*[@id='notToday']/label"), "오늘 하루 보이지 않기");
			if (isExist1) {
				// 오늘 하루 보지 않기 버튼 클릭
				driver.findElement(By.xpath(".//*[@id='notToday']/label")).click();
				System.out.println("오늘 하루 보지 않기 버튼 클릭");
				Thread.sleep(3000);
			} else {
				// 알럿이 없는 경우
				System.out.println("알럿 없음 다음 내용 수행");
				Thread.sleep(3000);
			}

			driver.findElement(By.linkText("TV쇼핑")).click();
			System.out.println("TV쇼핑 탭 이동");
			Thread.sleep(3000);
			
			// 쇼크라이브
			driver.findElement(By.linkText("쇼크LIVE")).click();
			System.out.println("쇼크LIVE 진입");
			Thread.sleep(3000);
					
	        WebElement searchBtn = driver.findElement(By.cssSelector("#moduleArea > div.module_bx.dm0027"));
	        Actions action = new Actions(driver);
	        action.moveToElement(searchBtn).build().perform();
	        Thread.sleep(3000);
	        
			// 편성표 보기 버튼 클릭
			driver.findElement(By.cssSelector("#moduleArea > div.module_bx.dm0027 > div > div > a > div.btn_area > button > span")).click();
			System.out.println("편성표 보기 클릭. 편성표 진입");
			Thread.sleep(3000);
			//driver.findElement(By.cssSelector("#scheduleDate > div > ul > li:nth-child(10) > a")).click();
			//Thread.sleep(3000);	
			
			
			
			ShockLive = "쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
			BbunFun = "뻔FUN한 가게".equals(driver.findElement(By.xpath("//*[@id=\"header\"]/div/h1/a/img")).getText());			
			isExist2 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[1]"), "단품");
			if(!isExist2) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[2]/a")).click();
				System.out.println("2번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("2번째 상품으로 넘어갑니다.");
				}
			
			isExist3 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[3]"), "3번째 상품");
			if(!isExist3) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[2]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[3]/a")).click();
				System.out.println("3번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("3번째 상품으로 넘어갑니다.");
				}
			
			isExist4 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[4]"), "4번째 상품");
			if(!isExist4) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[3]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[4]/a")).click();
				System.out.println("4번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}			
				}else {
					System.out.println("4번째 상품으로 넘어갑니다.");
				}
			
			isExist5 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[5]"), "5번째 상품");
			if(!isExist5) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[4]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[5]/a")).click();
				System.out.println("5번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("5번째 상품으로 넘어갑니다.");
				}
			
			isExist6 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[6]"), "6번째 상품");
			if(!isExist6) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[5]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[6]/a")).click();
				System.out.println("6번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("6번째 상품으로 넘어갑니다.");
				}
			
			isExist7 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[7]"), "7번째 상품");
			if(!isExist7) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[6]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[7]/a")).click();
				System.out.println("7번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("7번째 상품으로 넘어갑니다.");
				}
			
			isExist8 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[8]"), "8번째 상품");
			if(!isExist8) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[7]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[8]/a")).click();
				System.out.println("8번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("8번째 상품으로 넘어갑니다.");
				}
			
			isExist9 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[9]"), "9번째 상품");
			if(!isExist9) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[8]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[9]/a")).click();
				System.out.println("9번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("9번째 상품으로 넘어갑니다.");
				}
			
			isExist10 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[10]"), "10번째 상품");
			if(!isExist10) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[9]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[10]/a")).click();
				System.out.println("10번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					System.out.println("10번째 상품으로 넘어갑니다.");
				}
			
			
			isExist11 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[11]"), "상품 10개 이상 일 경우");
			if(!isExist11) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[10]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[11]/a")).click();
				System.out.println("11번째 상품이 없습니다. ");
				Thread.sleep(3000);
				if(ShockLive || BbunFun) {
					System.out.println("예고방송페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
				
				}else {
					
					System.out.println("TC_FAIL");
					assertTrue(false);
					return;
				}
			}
			
			
			
			// 바로가기 버튼 선택
			//단품일 경우
			//3번 상품 없을 경우
			/*
			ShockLive = "쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
			BbunFun = "뻔FUN한 가게".equals(driver.findElement(By.xpath("//*[@id=\"header\"]/div/h1/a/img")).getText());			
			isExist2 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[1]"), "단품");
			isExist3 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[3]"), "3번째 상품");
			if(!isExist2) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[2]/a")).click();
				System.out.println("2번째 상품이 없습니다. ");
				Thread.sleep(3000);
				assertTrue(true);
				return;
				}else {
					if(!isExist3) {
						driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[2]")).click();
						driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[3]/a")).click();
						Thread.sleep(3000);
						"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
						System.out.println("3번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
						assertTrue(true);
						return;
					}else {
							System.out.println("3번째 상품이 존재합니다. 다음 상품으로 이동합니다.");
							
					}
				}
			
			//4번,5번 상품 없을 경우
			isExist4 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[4]"), "4번째 상품");
			isExist5 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[5]"), "5번째 상품");
			if(!isExist4) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[3]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[4]/a")).click();
				Thread.sleep(3000);
				"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
				System.out.println("4번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
				assertTrue(true);
				return;
			}else {
				if(!isExist5) {
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[4]")).click();
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[5]/a")).click();
					Thread.sleep(3000);
					"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
					System.out.println("5번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}else {
					System.out.println("5번째 상품이 존재합니다. 다음 상품으로 이동합니다.");
					
					
				}
				
			}
			//6번,7번 상품 없을 경우
			isExist6 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[6]"), "6번째 상품");
			isExist7 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[7]"), "7번째 상품");
			if(!isExist6) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[5]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[6]/a")).click();
				Thread.sleep(3000);
				"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
				System.out.println("6번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
				assertTrue(true);
				return;
			}else {
				if(!isExist7) {
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[6]")).click();
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[7]/a")).click();
					Thread.sleep(3000);
					"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
					System.out.println("7번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}else {
					System.out.println("7번째 상품이 존재합니다. 다음 상품으로 이동합니다.");
					Thread.sleep(3000);
				}
				
			}		
			//8번,9번 상품 없을 경우
			isExist8 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[8]"), "8번째 상품");
			isExist9 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[9]"), "9번째 상품");
			if(!isExist8) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[7]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[8]/a")).click();
				Thread.sleep(3000);
				"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
				System.out.println("8번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
				assertTrue(true);
				return;
			}else {
				if(!isExist9) {
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[8]")).click();
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[9]/a")).click();
					Thread.sleep(3000);
					"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
					System.out.println("9번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}else {
					System.out.println("9번째 상품이 존재합니다. 다음 상품으로 이동합니다.");
					Thread.sleep(3000);
				}
				
			}
			//10번 상품 없을 경우
			//10번 상품 있을 경우
			isExist10 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[10]"), "10번째 상품");
			isExist11 = existElement(driver, By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[11]"), "상품 10개 이상 일 경우");
			if(!isExist10) {
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[9]")).click();
				driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[10]/a")).click();
				Thread.sleep(3000);
				"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
				
				System.out.println("10번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
				assertTrue(true);
				return;
			}else {
				if(!isExist11) {
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/div/div/span[10]")).click();
					driver.findElement(By.xpath("//*[@id=\"schedulePgm\"]/div[1]/div[2]/div[2]/ul/li[11]/a")).click();
					Thread.sleep(3000);
					"쇼크LIVE".equals(driver.findElement(By.xpath(".//*[@id='header']/div/h1")).getText());
					System.out.println("11번째 상품이 없습니다. 예고방송 페이지 진입. 종료합니다.");
					assertTrue(true);
					return;
				}
			}*/
			
	

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}
	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		// wait.ignoring(NoSuchElementException.class);

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}

}
